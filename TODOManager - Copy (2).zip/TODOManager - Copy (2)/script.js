let taskList = document.getElementById("taskList");
let taskInput = document.getElementById("taskInput");
let statusMessage = document.getElementById("statusMessage");
let totalTasks = 0;
let completedTasks = 0;

function updateCounts() {
  document.getElementById("totalTasks").textContent = totalTasks;
  document.getElementById("completedTasks").textContent = completedTasks;
}

function showMessage(message, isError = false) {
  statusMessage.textContent = message;
  statusMessage.style.color = isError ? "lightcoral" : "lightgreen";
}

function addTask() {
  const taskText = taskInput.value.trim();

  if (taskText === "") {
    showMessage("Please enter a task.", true);
    return;
  }

  // Prevent duplicate
  const allTasks = document.getElementsByTagName("li");
  for (let item of allTasks) {
    if (item.querySelector(".task-text").textContent === taskText) {
      showMessage("Duplicate task!", true);
      return;
    }
  }

  let li = document.createElement("li");
  let span = document.createElement("span");
  span.className = "task-text";
  span.textContent = taskText;

  // Auto highlight if contains keywords
  if (/urgent|important/i.test(taskText)) {
    li.classList.add("highlighted");
  }

  let editBtn = createButton("Edit", () => editTask(span));
  let doneBtn = createButton("Done", () => markDone(span, li));
  let delBtn = createButton("Delete", () => deleteTask(li, span));
  let highlightBtn = createButton("Highlight", () => toggleHighlight(li));

  li.appendChild(span);
  li.appendChild(editBtn);
  li.appendChild(doneBtn);
  li.appendChild(highlightBtn);
  li.appendChild(delBtn);
  taskList.appendChild(li);

  totalTasks++;
  updateCounts();
  showMessage("Task added successfully!");
  taskInput.value = "";
}

function createButton(text, onClick) {
  let btn = document.createElement("button");
  btn.textContent = text;
  btn.onclick = onClick;
  btn.style.marginLeft = "5px";
  return btn;
}

function editTask(span) {
  let newText = prompt("Edit your task:", span.textContent);
  if (newText && newText.trim() !== "") {
    span.textContent = newText.trim();
    showMessage("Task updated.");
  }
}

function markDone(span, li) {
  if (!span.classList.contains("completed")) {
    span.classList.add("completed");
    completedTasks++;
    updateCounts();
    showMessage("Task marked as done.");
  }
}

function deleteTask(li, span) {
  if (span.classList.contains("completed")) completedTasks--;
  li.remove();
  totalTasks--;
  updateCounts();
  showMessage("Task deleted.");
}

function toggleHighlight(li) {
  li.classList.toggle("highlighted");
}
